import test from 'node:test';
import assert from 'node:assert/strict';
import { newGame, applyAction, legalActions, rng, observation } from '../../kingdomino/core.js';
import { createSearch, runSearch, summary } from '../../kingdomino/ai.js';
import { runMeasured, playGame } from './run.mjs';

test('measured evaluation runner preserves production search choices and accounting', () => {
  let state=newGame({mode:'digital',seed:881002}),random=rng(881013),samples=[];
  while(state.phase!=='gameover') {
    if(state.phase==='place'&&[0,12,20].includes(state.seen.length)&&samples.length<3)samples.push(observation(state));
    const actions=legalActions(state);state=applyAction(state,actions[Math.floor(random()*actions.length)]);
  }
  assert.equal(samples.length,3);
  for(let i=0;i<samples.length;i++) {
    const seed=9921+i,a=createSearch(samples[i],{seed,horizon:6,beam:12}),b=createSearch(samples[i],{seed,horizon:6,beam:12});
    const metrics=runMeasured(a,48);runSearch(b,48);
    assert.deepEqual(summary(a),summary(b),`stage ${i}`);assert.equal(metrics.iterations,48);assert.equal(metrics.sampledContinuations,48);
  }
});

test('measured runner stops solved final-row searches without padding', () => {
  let state=newGame({mode:'digital',seed:66102}),random=rng(66119),final;
  while(state.phase!=='gameover') {
    if(state.phase==='place'&&state.offer.length===0)final=observation(state);
    const actions=legalActions(state);state=applyAction(state,actions[Math.floor(random()*actions.length)]);
  }
  assert.ok(final);
  const a=createSearch(final,{seed:7,horizon:6,beam:12}),b=createSearch(final,{seed:7,horizon:6,beam:12});
  const metrics=runMeasured(a,300);runSearch(b,300);
  assert.deepEqual(summary(a),summary(b));assert.equal(metrics.solved,true);assert.equal(metrics.iterations,a.arms.length);assert.equal(metrics.sampledContinuations,0);
});

test('paired setup keeps the deal fixed while reversing only candidate seat', async () => {
  const c={id:'smoke-pair',candidate:2,opponent:'tuned',opponentType:'heuristic'};
  const a=await playGame(c,0),b=await playGame(c,1);
  assert.equal(a.candidateSeat,0);assert.equal(b.candidateSeat,1);
  assert.equal(a.gameSeed,b.gameSeed);assert.deepEqual(a.initialKingOrder,b.initialKingOrder);
  for(const game of [a,b]) {
    assert.equal(game.replayOracle.result,'passed');
    assert.deepEqual([...game.winnerSeats].sort(),[...game.independentOracleWinnerSeats].sort());
    assert.ok(game.decisions.candidate.decisionCount>0);
  }
});
