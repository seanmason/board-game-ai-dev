import { createHash } from 'node:crypto';
import { cpus } from 'node:os';
import { readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import { newGame, applyAction, legalActions, currentPlayer, observation, rng, score, winners, assertValid, determinize } from '../../kingdomino/core.js';
import { createSearch, summary, policy, value } from '../../kingdomino/ai.js';
import { referenceActions, referenceStep, referenceScores } from '../../test/kingdomino-reference.js';

const args = Object.fromEntries(process.argv.slice(2).filter(x => x.startsWith('--')).map(x => x.slice(2).split('=')));
const OUT = fileURLToPath(new URL('./results.json', import.meta.url));
const CFG = fileURLToPath(new URL('./config.json', import.meta.url));
const CAL = fileURLToPath(new URL('./calibration.json', import.meta.url));
const STOP = fileURLToPath(new URL('./STOP', import.meta.url));
let stopRequested = false;
const PLAN = {
  title: 'Kingdomino search budget evaluation', game: 'Kingdomino', edition: 'original', players: 2,
  seedBase: 67450291, seedStride: 104729, firstThreeGamesPerComparison: 24, pairedSetupSeeds: 12,
  longProbeGames: 12, longProbePairedSeeds: 6, search: { horizon: 6, beam: 12, rolloutPolicy: 'stochastic', evaluator: 'existing kingdomino/ai.js value and terminalValue', tieBreaking: 'existing root-bandit order; independent per-decision RNG' },
  comparisons: [
    { id: '3000-vs-300', candidate: 3000, opponent: 300, opponentType: 'search', games: 24, pairs: 12 },
    { id: '3000-vs-tuned', candidate: 3000, opponent: 'tuned', opponentType: 'heuristic', games: 24, pairs: 12 },
    { id: '300-vs-tuned', candidate: 300, opponent: 'tuned', opponentType: 'heuristic', games: 24, pairs: 12 },
    { id: '10000-vs-3000', candidate: 10000, opponent: 3000, opponentType: 'search', games: 12, pairs: 6 }
  ],
  heldoutSeedPolicy: 'Fixed before tournament: 67450291 + pairIndex * 104729; each pair is replayed with candidate seat 0 then seat 1. Development/previous Kingdomino runs used different seeds.',
  accounting: 'One root-bandit iteration is one independent hidden-world determinization and stochastic rollout from a legal root action. No transposition tree exists, so unique tree nodes and terminal tree revisits are not applicable. Solved final placements are exact exhaustive continuations and stop immediately; their actual arm count is recorded and no iterations are padded.',
  noHiddenInformation: 'Game deck drives only actual game transitions. Search receives observation() and determinize() samples from unseen dominoes; heuristic receives observation() only.',
  // Keep the original timestamp stable on resume; otherwise a dynamic plan field
  // would make every later invocation appear to change the frozen experiment.
  createdAt: existsSync(CFG) ? JSON.parse(readFileSync(CFG, 'utf8')).plan.createdAt : new Date().toISOString()
};

function sha(path) { return createHash('sha256').update(readFileSync(new URL('../../' + path, import.meta.url))).digest('hex'); }
const sourceFiles = ['kingdomino/core.js','kingdomino/ai.js','kingdomino/catalog.js','test/kingdomino-reference.js','benchmarks/kingdomino-budget/run.mjs','benchmarks/kingdomino-budget/run.test.mjs'];
const sourceCommit = execFileSync('git', ['rev-parse','HEAD'], {encoding:'utf8'}).trim();
const sourceHashes = Object.fromEntries(sourceFiles.map(p => [p, sha(p)]));
function hashSeed(...parts) { return parseInt(createHash('sha256').update(parts.join(':')).digest('hex').slice(0,8),16); }
function atomicallySave(data) { const tmp = OUT + '.tmp'; writeFileSync(tmp, JSON.stringify(data)); renameSync(tmp, OUT); }
function runtimeInfo() { return {node:process.version,platform:process.platform,arch:process.arch,cpu:cpus()[0]?.model,availableCpuCount:cpus().length,processIsolation:'single process; no worker pools'}; }

// This is a behavior-preserving copy of runSearch with counters around the actual rollout.
export function runMeasured(q, budget) {
  const stats = { iterations:0, rootActions:q.arms.length, rootActionsVisited:0, sampledContinuations:0, continuationPlies:0, maxContinuationPlies:0, rolloutTerminalCount:0, solved:q.solved, exactSolvedArmCount:q.solved?q.arms.length:0 };
  if (q.solved) { stats.iterations=q.iterations; stats.rootActionsVisited=q.arms.filter(a=>a.visits).length; return stats; }
  for (let k=0;k<budget;k++) {
    const width=Math.min(q.arms.length,Math.max(6,Math.floor(6+Math.sqrt(q.iterations)*2))), active=q.arms.slice(0,width);
    const unvisited=active.find(a=>!a.visits), topPrior=q.arms[0].prior;
    const estimate=a=>a.sum/a.visits+2.2*Math.sqrt(Math.log(q.iterations+2)/a.visits)+.15*(a.prior-topPrior)/(1+a.visits*.05);
    const arm=unvisited??active.reduce((a,b)=>estimate(b)>estimate(a)?b:a);
    if (arm.exact!==undefined) { arm.visits++;arm.sum+=arm.exact;arm.squares+=arm.exact*arm.exact;q.iterations++;stats.iterations++;continue; }
    let s=determinize(q.o,q.random);s=applyAction(s,arm.action,{validate:false});let plies=0;
    for (;plies<q.horizon&&s.phase!=='gameover';plies++) s=applyAction(s,policy(s,q.random,'stochastic'),{validate:false});
    const utility=s.phase==='gameover' ? terminalUtility(s,q.actor) : value(s,q.actor);
    arm.visits++;arm.sum+=utility;arm.squares+=utility*utility;q.iterations++;
    stats.iterations++;stats.sampledContinuations++;stats.continuationPlies+=plies;stats.maxContinuationPlies=Math.max(stats.maxContinuationPlies,plies);if(s.phase==='gameover')stats.rolloutTerminalCount++;
  }
  stats.rootActionsVisited=q.arms.filter(a=>a.visits).length;
  return stats;
}
function terminalUtility(s, who) { const ours=score(s.players[who]), theirs=Math.max(...s.players.map((p,i)=>i===who?-Infinity:score(p)));return ours-theirs+(winners(s).includes(who)?12:0); }
function setupMetrics() { return { wallMs:0,cpuMs:0,decisionCount:0,iterations:0,rootLegal:0,rootVisited:0,sampledContinuations:0,continuationPlies:0,rolloutTerminalCount:0,solvedDecisions:0,exactSolvedArms:0,uniqueEvaluatedTreeNodes:null,terminalTreeRevisits:null,decisionMetrics:[] }; }
function searchAction(state, gameSeed, comparisonId, gameIndex, actor, actionIndex, budget) {
  const wall0=performance.now(),cpu0=process.cpuUsage(),obs=observation(state),seed=hashSeed('decision-search',gameSeed,comparisonId,gameIndex,actor,actionIndex),q=createSearch(obs,{seed,horizon:PLAN.search.horizon,beam:PLAN.search.beam});
  const accounting=runMeasured(q,budget),choice=summary(q).candidates[0].action,wallMs=performance.now()-wall0,cpu=process.cpuUsage(cpu0),cpuMs=(cpu.user+cpu.system)/1000;
  return {choice,metric:{...accounting,phase:obs.phase,round:obs.round,seen:obs.seen.length,wallMs,cpuMs,legalRootActions:accounting.rootActions,visitedRootActions:accounting.rootActionsVisited,configuredBudget:budget,iterations:accounting.iterations,depth:{configuredHorizon:PLAN.search.horizon,maxObservedPlies:accounting.maxContinuationPlies,meanObservedPlies:accounting.sampledContinuations?accounting.continuationPlies/accounting.sampledContinuations:0}}};
}
function assertOracleStep(prod, oracle, action, context) {
  const actual=legalActions(prod), independent=referenceActions(oracle);
  const key=x=>JSON.stringify(x);
  if([...actual].map(key).sort().join('|')!==[...independent].map(key).sort().join('|'))throw Error(`oracle legal action mismatch ${context}`);
  const a=applyAction(prod,action);const b=referenceStep(oracle,action);
  if(!isDeepStrictEqual(a,b))throw Error(`oracle transition mismatch ${context}`);
  assertValid(a);return [a,b];
}
function scoreAudit(s, context) {
  for(let i=0;i<s.players.length;i++)if(score(s.players[i])!==referenceScores(s.players[i].board).score)throw Error(`oracle score mismatch ${context}/player${i}`);
}
function oracleWinners(s) {
  const rows=s.players.map((p,player)=>({player,...referenceScores(p.board)}));
  const cmp=(a,b)=>b.score-a.score||b.largest-a.largest||(s.edition==='original'?b.crowns-a.crowns:0);
  rows.sort(cmp);return rows.filter(r=>cmp(rows[0],r)===0).map(r=>r.player);
}
export async function playGame(c, gameIndex) {
  const pairIndex=Math.floor(gameIndex/2),candidateSeat=gameIndex%2,gameSeed=PLAN.seedBase+pairIndex*PLAN.seedStride;
  let s=newGame({mode:'digital',edition:PLAN.edition,players:2,seed:gameSeed}),oracle=structuredClone(s),actionIndex=0;
  const actions=[],decisions={candidate:setupMetrics(),opponent:setupMetrics()},timing0=performance.now(),cpu0=process.cpuUsage();
  while(s.phase!=='gameover') {
    const actor=currentPlayer(s),isCandidate=actor===candidateSeat,side=isCandidate?'candidate':'opponent';let action;
    if(isCandidate||c.opponentType==='search') {
      const budget=isCandidate?c.candidate:Number(c.opponent),out=searchAction(s,gameSeed,c.id,gameIndex,actor,actionIndex,budget);action=out.choice;
      const m=out.metric,d=decisions[side];d.wallMs+=m.wallMs;d.cpuMs+=m.cpuMs;d.decisionCount++;d.iterations+=m.iterations;d.rootLegal+=m.legalRootActions;d.rootVisited+=m.visitedRootActions;d.sampledContinuations+=m.sampledContinuations;d.continuationPlies+=m.continuationPlies;d.rolloutTerminalCount+=m.rolloutTerminalCount;d.solvedDecisions+=m.solved?1:0;d.exactSolvedArms+=m.exactSolvedArmCount;d.decisionMetrics.push(m);
    } else {
      const obs=observation(s),random=rng(hashSeed('decision-heuristic',gameSeed,c.id,gameIndex,actor,actionIndex));action=policy(obs,random,'tuned');
    }
    const [next,nextOracle]=assertOracleStep(s,oracle,action,`${c.id}/${gameIndex}/${actionIndex}`);
    actions.push({player:actor,action});s=next;oracle=nextOracle;scoreAudit(s,`${c.id}/${gameIndex}/${actionIndex}`);actionIndex++;
    // Yield so SIGINT/SIGTERM can be handled during a long synchronous search game.
    await new Promise(resolve => setImmediate(resolve));
  }
  const scores=s.players.map(score),win=winners(s),independentWinners=oracleWinners(s),margin=scores[candidateSeat]-scores[1-candidateSeat];
  if(JSON.stringify([...win].sort())!==JSON.stringify([...independentWinners].sort()))throw Error(`independent oracle winner/tiebreak mismatch ${c.id}/${gameIndex}`);
  // Full replay begins from the seed and uses the separately implemented transition and legality oracle.
  let replay=newGame({mode:'digital',edition:PLAN.edition,players:2,seed:gameSeed});for(let i=0;i<actions.length;i++){const {player,action}=actions[i];if(currentPlayer(replay)!==player)throw Error(`replay actor mismatch ${c.id}/${gameIndex}/${i}`);[replay,replay]=assertOracleStep(replay,replay,action,`replay/${c.id}/${gameIndex}/${i}`);scoreAudit(replay,`replay/${c.id}/${gameIndex}/${i}`);} // Both transition implementations must reconstruct the recorded action stream.
  if(!isDeepStrictEqual(replay,s))throw Error(`final replay state mismatch ${c.id}/${gameIndex}`);
  return {gameIndex,pairIndex,gameSeed,candidateSeat,initialKingOrder:s.initialOrder,score:scores,winnerSeats:win,independentOracleWinnerSeats:independentWinners,candidateWinShare:independentWinners.includes(candidateSeat)?1/independentWinners.length:0,scoreMargin:margin,turns:actions.length,actions,decisions,gameWallMs:performance.now()-timing0,gameCpuMs:(()=>{const x=process.cpuUsage(cpu0);return (x.user+x.system)/1000;})(),runtime:runtimeInfo(),replayOracle:{legalActionChecks:actions.length,transitionChecks:actions.length,scoreChecks:(actions.length+1)*2,result:'passed'}};
}

async function runTournament() {
  const planHash=createHash('sha256').update(JSON.stringify(PLAN)).digest('hex');
  if(!existsSync(CFG))writeFileSync(CFG,JSON.stringify({plan:PLAN,planHash,sourceCommit,sourceHashes,runtime:runtimeInfo(),frozenAt:new Date().toISOString()},null,2)+'\n');
  const config=JSON.parse(readFileSync(CFG,'utf8'));if(config.planHash!==planHash)throw Error('Frozen config does not match this script; refuse to resume with changed setup.');if(JSON.stringify(config.sourceHashes)!==JSON.stringify(sourceHashes))throw Error('Frozen source hashes differ. Use --migrate-resume=1 to record a harness-only source migration before resuming.');
  let data=existsSync(OUT)?JSON.parse(readFileSync(OUT,'utf8')):{planHash,sourceCommit,sourceHashes,comparisons:{},startedAt:new Date().toISOString()};if(data.planHash!==planHash||JSON.stringify(data.sourceHashes)!==JSON.stringify(sourceHashes))throw Error('Output plan/source hash mismatch.');
  for(const c of PLAN.comparisons){data.comparisons[c.id]??={spec:c,games:[]};const done=new Set(data.comparisons[c.id].games.map(g=>g.gameIndex));for(let i=0;i<c.games;i++){if(done.has(i))continue;if(stopRequested||existsSync(STOP)){data.stoppedAtCheckpoint=new Date().toISOString();data.stopReason=stopRequested?'signal requested':'STOP file present';atomicallySave(data);console.error(`Stopping before ${c.id} game ${i}; completed-game checkpoint saved.`);return;}const game=await playGame(c,i);data.comparisons[c.id].games.push(game);data.comparisons[c.id].games.sort((a,b)=>a.gameIndex-b.gameIndex);data.updatedAt=new Date().toISOString();atomicallySave(data);const wins=data.comparisons[c.id].games.reduce((n,g)=>n+g.candidateWinShare,0);console.error(`${c.id} game ${i+1}/${c.games}: seat ${game.candidateSeat}, scores ${game.score.join('-')}, candidate win share ${game.candidateWinShare}, wall ${game.gameWallMs.toFixed(1)}ms; completed ${data.comparisons[c.id].games.length}, W-share ${wins}/${data.comparisons[c.id].games.length}`);if(stopRequested||existsSync(STOP)){data.stoppedAtCheckpoint=new Date().toISOString();data.stopReason=stopRequested?'signal requested':'STOP file present';atomicallySave(data);console.error('Stopping at completed-game checkpoint.');return;}}}
  data.finishedAt=new Date().toISOString();atomicallySave(data);console.log(JSON.stringify({finishedAt:data.finishedAt,counts:Object.fromEntries(Object.entries(data.comparisons).map(([k,v])=>[k,v.games.length]))},null,2));
}

function calibration() {
  // Build public representative snapshots using a deterministic legal random baseline.
  const checkpoints=[{label:'early',seenAt:0},{label:'middle',seenAt:12},{label:'late',seenAt:20}],states={};let s=newGame({mode:'digital',seed:4510021}),r=rng(4510039),i=0;
  while(s.phase!=='gameover') { for(const cp of checkpoints)if(!states[cp.label]&&s.seen.length>=cp.seenAt&&s.phase==='place')states[cp.label]=observation(s);const as=legalActions(s);s=applyAction(s,as[Math.floor(r()*as.length)]);i++;if(i>100)break; }
  const budgets=[300,3000,10000],rows=[];
  for(const cp of checkpoints)for(const budget of budgets){const o=states[cp.label];if(!o)throw Error(`missing calibration state ${cp.label}`);for(const repeat of [0]){const w0=performance.now(),c0=process.cpuUsage(),q=createSearch(o,{seed:hashSeed('calibration',cp.label,budget,repeat),horizon:PLAN.search.horizon,beam:PLAN.search.beam}),stats=runMeasured(q,budget),s=summary(q),wallMs=performance.now()-w0,cpu=process.cpuUsage(c0);rows.push({stage:cp.label,phase:o.phase,round:o.round,seen:o.seen.length,budget,...stats,topAction:s.candidates[0].action,wallMs,cpuMs:(cpu.user+cpu.system)/1000,legalActions:q.arms.length,rootCoverage:stats.rootActionsVisited/q.arms.length,uniqueEvaluatedTreeNodes:null,terminalTreeRevisits:null});}}
  const byBudget=summarizeBudgets(rows,budgets);
  const projections={};for(const c of PLAN.comparisons){const sampleCount=c.games*24*(c.candidate+(c.opponentType==='search'?Number(c.opponent):0));const msPerIteration=byBudget[3000].meanCpuMs/3000;projections[c.id]={approxSearchIterations:sampleCount,estimatedCpuHours:sampleCount*msPerIteration/3600000};}
  const totalCpuHours=Object.values(projections).reduce((n,x)=>n+x.estimatedCpuHours,0),out={plan:PLAN,sourceCommit,sourceHashes,runtime:{node:process.version,platform:process.platform,arch:process.arch,cpu:cpus()[0]?.model,availableCpuCount:cpus().length},representativeSnapshotSeed:4510021,calibrationRows:rows,budgetSummary:byBudget,projection:{assumption:'All searched decisions average 24 per game; solved late decisions may reduce actual iterations. Uses 3,000-iteration mean CPU cost.',comparisons:projections,totalEstimatedCpuHours:totalCpuHours,totalEstimatedWallHoursAtOneProcess:totalCpuHours}};
  writeFileSync(CAL,JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out.projection,null,2));
}
function summarizeBudgets(rows,budgets=[300,3000,10000]) {return Object.fromEntries(budgets.map(b=>{const rs=rows.filter(x=>x.budget===b);return [b,{medianWallMs:median(rs.map(x=>x.wallMs)),meanWallMs:avg(rs.map(x=>x.wallMs)),medianCpuMs:median(rs.map(x=>x.cpuMs)),meanCpuMs:avg(rs.map(x=>x.cpuMs)),meanIterations:avg(rs.map(x=>x.iterations)),meanRolloutPlies:avg(rs.map(x=>x.continuationPlies))}]}));}
function reanalyzeCalibration() {
  const out=JSON.parse(readFileSync(CAL,'utf8')),budgets=[300,3000,10000];out.sourceHashes=sourceHashes;out.budgetSummary=summarizeBudgets(out.calibrationRows,budgets);const projections={};for(const c of PLAN.comparisons){const sampleCount=c.games*24*(c.candidate+(c.opponentType==='search'?Number(c.opponent):0)),msPerIteration=out.budgetSummary[3000].meanCpuMs/3000;projections[c.id]={approxSearchIterations:sampleCount,estimatedCpuHours:sampleCount*msPerIteration/3600000};}const totalCpuHours=Object.values(projections).reduce((n,x)=>n+x.estimatedCpuHours,0);out.projection={assumption:'All searched decisions average 24 per game; solved late decisions may reduce actual iterations. Uses root-inclusive 3,000-iteration mean CPU cost.',comparisons:projections,totalEstimatedCpuHours:totalCpuHours,totalEstimatedWallHoursAtOneProcess:totalCpuHours};writeFileSync(CAL,JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out.projection,null,2));
}
function migrateResume() {
  const planHash=createHash('sha256').update(JSON.stringify(PLAN)).digest('hex'),config=JSON.parse(readFileSync(CFG,'utf8')),data=JSON.parse(readFileSync(OUT,'utf8'));
  if(config.planHash!==planHash||data.planHash!==planHash)throw Error('Cannot migrate: frozen experiment plan hash differs.');
  const oldHashes=config.sourceHashes??{};
  for(const key of ['kingdomino/core.js','kingdomino/ai.js','kingdomino/catalog.js','test/kingdomino-reference.js'])if(oldHashes[key]!==sourceHashes[key])throw Error(`Cannot migrate policy/rules source ${key}; this is not a harness-only migration.`);
  const previous={sourceHashes:oldHashes,runtime:config.runtime,frozenAt:config.frozenAt};
  config.sourceHashHistory??=[];
  if(JSON.stringify(config.sourceHashes)!==JSON.stringify(sourceHashes))config.sourceHashHistory.push({migratedAt:new Date().toISOString(),reason:'Windows-compatible checkpoint resume and per-game runtime metadata; no policy, rule, plan, seed, budget, or completed result changes.',previous,currentSourceHashes:sourceHashes,currentRuntime:runtimeInfo()});
  config.sourceHashes=sourceHashes;config.runtimeContinuations??=[];if(!config.runtimeContinuations.some(x=>x.node===process.version&&x.platform===process.platform&&x.arch===process.arch))config.runtimeContinuations.push({startedAt:new Date().toISOString(),...runtimeInfo()});
  config.migrationStatus='harness migration only; completed game records are preserved';writeFileSync(CFG,JSON.stringify(config,null,2)+'\n');
  data.sourceHashHistory??=[];if(JSON.stringify(data.sourceHashes)!==JSON.stringify(sourceHashes))data.sourceHashHistory.push({migratedAt:new Date().toISOString(),previousSourceHashes:data.sourceHashes,currentSourceHashes:sourceHashes,reason:'Windows-compatible checkpoint resume; policy/rules and outcomes unchanged.'});
  for(const c of Object.values(data.comparisons))for(const g of c.games)g.runtime??={...config.runtime,runtimeSource:'initial run config'};
  data.sourceHashes=sourceHashes;data.resumeMigration={migratedAt:new Date().toISOString(),reason:'Windows-compatible checkpoint resume; current partial game was not saved and will be replayed from its frozen deterministic seed.'};atomicallySave(data);
  console.log(JSON.stringify({migrated:true,completedGames:Object.fromEntries(Object.entries(data.comparisons).map(([k,v])=>[k,v.games.length])),sourceHashes:config.sourceHashes,runtime:runtimeInfo()},null,2));
}
function avg(xs){return xs.reduce((a,b)=>a+b,0)/Math.max(1,xs.length);}function median(xs){return [...xs].sort((a,b)=>a-b)[Math.floor(xs.length/2)];}

if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url){if(args.calibrate!==undefined)calibration();else if(args.summarize!==undefined)reanalyzeCalibration();else if(args['migrate-resume']!==undefined)migrateResume();else if(args.run!==undefined){process.on('SIGINT',()=>{stopRequested=true;console.error('SIGINT received; finishing current game before stopping.');});process.on('SIGTERM',()=>{stopRequested=true;console.error('SIGTERM received; finishing current game before stopping.');});await runTournament();}else throw Error('Use --calibrate=1, --summarize=1, --migrate-resume=1, or --run=1.');}
