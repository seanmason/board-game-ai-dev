# Kingdomino evaluation handoff

The frozen evaluation plan is in `config.json`; the initial Linux config and exact initial runner are preserved as `config.linux-start.json` and `run.frozen.mjs`. The evaluation harness and paired-seat/replay tests are in `run.mjs` and `run.test.mjs`. The study is unfinished: 2 of 84 games are complete. Both are the seat-reversed pair for `3000-vs-300`, setup seed 67450291; all other comparisons have zero completed games. The 3,000-budget candidate won 65–16 from seat 0 and lost 37–12 from seat 1. Both full traces passed the independent legality, transition, score, and official-winner oracle checks. No completed result was discarded.

The tournament was stopped after game index 1 was atomically checkpointed. An in-progress game index 2 had not reached its save boundary; it was not recorded and will be rerun deterministically on resume. The schedule remains 24/12 pairs for each of the first three comparisons and 12/6 pairs for `10000-vs-3000`; no sample or budget reductions were made. Calibration projected about 19.10 single-core hours for the full schedule before solved-endgame savings.

The original execution used Node v24.19.0 on Linux x64. Completed game records include their runtime metadata, and future records carry the environment where they run. `run.mjs` supports Windows paths and can stop safely at a game boundary. Press Ctrl+C to finish the current game and stop, or create an empty `STOP` file beside the runner to stop before the next game or at the next completed-game boundary. Remove `STOP` before resuming.

From the repository root in PowerShell or Command Prompt, install/use Node 20 or newer and run:

```text
node --version
node --test benchmarks/kingdomino-budget/run.test.mjs
node benchmarks/kingdomino-budget/run.mjs --migrate-resume=1
node benchmarks/kingdomino-budget/run.mjs --run=1
```

The migration command verifies that the frozen plan and game policy/rules sources are unchanged, transparently records the harness-source migration and continuation runtime, and updates hashes without starting games. The runner resumes only missing game indices from `results.json`; game 2 of `3000-vs-300` is the first missing index. Do not rerun the Linux calibration for the Windows continuation: its latency measurements are platform-specific. After the full study finishes, generate the report with:

```text
node benchmarks/kingdomino-budget/report.mjs
```

To inspect the original frozen runner/config or compare source hashes, use `run.frozen.mjs` and `config.linux-start.json`. The migration preserves `results.json` traces and adds source-hash history rather than overwriting provenance.
