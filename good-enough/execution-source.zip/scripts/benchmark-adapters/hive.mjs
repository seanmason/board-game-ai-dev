import {performance} from 'node:perf_hooks';
import {createHash} from 'node:crypto';
import {newGame,legalActions,applyAction,assertValid,outcome,boardResult,positionKey} from '../../hive/core.js';
import {createSearch,runSearch,summarizeSearch} from '../../hive/ai.js';
import {actionKey,locate} from '../../hive/actions.js';
import {PIECES,queenId} from '../../hive/catalog.js';
import {neighbors,height,coordinate,lift,connected,rotate,reflect} from '../../hive/geometry.js';
import {publicObservation} from '../../hive/observations.js';
import * as incumbent from './hive-incumbent.mjs';
import * as history from './hive-history.mjs';

export const metadata={game:'hive',supportedPlayers:[2],defaultBudget:{ms:100,maxTurns:160,repetitionLimit:4,openingPlies:0},scope:'match',
 historyPolicyId:'hive-public-history-tiebreak-v1',policyId:'hive-tactical-guard-v2',incumbentPolicyId:'hive-production-alphabeta-v1',opponentPolicyId:'hive-independent-tactical-liberties-v1',
 limitations:['Classic Hive publisher diagram certification remains open.','Candidate requires the tactical gate and completed depth-one floor; incumbent requires the original depth-one floor. Search policies use the configured soft time budget and report actual overruns.','Independent baseline remains available separately from frozen incumbent comparison.','Explicit openingPlies:6 enables full matches from seeded legal nonterminal openings, identical across seat rotations; default0 retains the original empty setup. Opening signatures identify duplicate setups.','Repeated positions and caps are unresolved, not automatic draws.','A paused browser search with an unfinished tactical gate withholds advice and can be resumed.']};
const latency=values=>{const v=[...values].sort((a,b)=>a-b);return {count:v.length,totalMs:v.reduce((a,b)=>a+b,0),maxMs:v.at(-1)??0,p50Ms:v.length?v[Math.floor((v.length-1)*.5)]:0,p95Ms:v.length?v[Math.ceil((v.length-1)*.95)]:0};};
const hash=(seed,key)=>{let n=seed>>>0;for(const c of key)n=Math.imul(n^c.charCodeAt(0),16777619)>>>0;return n;};
/** Benchmark-only opening generation: no candidate or opponent policy participates. */
export function generateOpening({seed=1,openingPlies=0}={}){
 if(!Number.isInteger(seed)||seed<0||seed>0xffffffff||!Number.isInteger(openingPlies)||openingPlies<0||openingPlies>32)throw Error('Invalid Hive opening seed/plies');
 for(let attempt=0;attempt<128;attempt++){
  let state=newGame({mode:'digital',startingPlayer:seed%2}),random=(seed^0x9e3779b9^Math.imul(attempt,0x85ebca6b))>>>0;
  const actionKeys=[];let rejected=false;
  for(let ply=0;ply<openingPlies;ply++){
   const actions=legalActions(state).slice().sort((a,b)=>actionKey(a).localeCompare(actionKey(b)));
   if(!actions.length){rejected=true;break;}random=(Math.imul(random,1664525)+1013904223)>>>0;
   const action=actions[Math.floor(random/4294967296*actions.length)];state=applyAction(state,action);assertValid(state);actionKeys.push(actionKey(action));
   if(state.phase!=='play'){rejected=true;break;}
  }
  if(rejected)continue;
  const key=positionKey(state),symmetryKeys=[];
  for(const mirrored of [false,true])for(let turns=0;turns<6;turns++){
   const board=Object.fromEntries(Object.entries(state.board).map(([at,stack])=>{let point=coordinate(at);if(mirrored)point=reflect(point);for(let i=0;i<turns;i++)point=rotate(point);return [point.join(','),stack];}));
   symmetryKeys.push(positionKey({...state,board}));
  }
  const canonicalSignature=symmetryKeys.sort()[0];
  return {state,diagnostics:{generator:'seeded-uniform-legal-prefix-v1',seed,plies:openingPlies,attempt,actionKeys,positionKey:key,canonicalSignature,sha256:createHash('sha256').update(canonicalSignature).digest('hex'),scope:openingPlies?'full-match-from-generated-opening':'full-match-from-empty-board'}};
 }
 throw Error('Unable to generate a legal nonterminal opening within128 deterministic attempts');
}
function liberties(s,seat){const q=locate(s.board,queenId(seat));return q?neighbors(q.at).filter(p=>height(s.board,p)===0).length:6;}
/** Independent one-ply material/mobility estimate; not the production evaluate function. */
function practicalValue(s,viewer){
 const result=boardResult(s);if(result)return result.winner===null?0:result.winner===viewer?1e6:-1e6;
 const freedom=seat=>{let movable=0,pins=0;for(const [at,stack]of Object.entries(s.board)){if(PIECES[stack.at(-1)].player!==seat)continue;
  if(connected(lift(s.board,coordinate(at))))movable++;if(stack.length>1&&PIECES[stack[0]].player!==seat)pins++;}
  return movable*1.5+pins*4+(11-s.reserves[seat].length)*.35;};
 return (liberties(s,viewer)-liberties(s,1-viewer))*14+freedom(viewer)-freedom(1-viewer);
}
/** Full immediate-win scan; highest-ranked safe move avoids every immediate reply win. */
export function chooseBaseline(state,{seed=1,replyChecks=true}={}){
 const viewer=state.currentPlayer,rows=legalActions(state).map(action=>{const child=applyAction(state,action);return {action,child,value:practicalValue(child,viewer),tie:hash(seed,actionKey(action))};});
 rows.sort((a,b)=>b.value-a.value||a.tie-b.tie);const win=rows.find(row=>boardResult(row.child)?.winner===viewer);if(win)return {action:win.action,replyNodes:0};
 let replyNodes=0;if(replyChecks)for(const row of rows){let loses=false;
  if(row.child.phase==='play')for(const reply of legalActions(row.child)){replyNodes++;if(boardResult(applyAction(row.child,reply))?.winner===1-viewer){loses=true;break;}}
  if(!loses)return {action:row.action,replyNodes};
 }
 return {action:rows[0]?.action??null,replyNodes};
}
export function chooseCandidate(observation,{ms=100,maxDepth=5,policy='tactical-v2'}={}){
 const api=policy==='incumbent-v1'?incumbent:policy==='history-v1'?history:{createSearch,runSearch,summarizeSearch};
 const search=api.createSearch({observation,maxDepth}),start=performance.now();let iterations=0,floorElapsedMs=null;
 while(!search.done&&(search.completedDepth===0||performance.now()-start<ms)){api.runSearch(search,1);iterations++;if(floorElapsedMs===null&&search.completedDepth>0)floorElapsedMs=performance.now()-start;}
 const summary=api.summarizeSearch(search);const fallback=false;
 // Unvisited/partially evaluated deeper roots never replace a completed result.
 const chosen=summary.candidates[0]?.action;
 return {action:chosen??null,diagnostics:{nodes:summary.nodes,iterations,completedDepth:summary.completedDepth,searchedRoots:summary.searchedRoots,legalRoots:summary.legalRoots,fallback,
  floorElapsedMs,floorOverrunMs:Math.max(0,(floorElapsedMs??0)-ms),tacticalReady:summary.tacticalReady??null,tacticalCounts:summary.tacticalCounts??null,tacticalReplyNodes:summary.tacticalReplyNodes??0,historyPolicy:summary.historyPolicy??null,selectedPreviousOccurrences:summary.selectedPreviousOccurrences??null,selectedRepeatedState:summary.selectedRepeatedState??null}};
}
export async function runGame({seed=1,seat=0,players=2,budget={},policy='production-default',opponent='simple-v1',scope='match'}={}){
 if(players!==2||![0,1].includes(seat))throw Error('Hive benchmark supports two players and seats0/1');
 const candidateKey=['production-default','tactical-v2',metadata.policyId].includes(policy)?'tactical-v2':policy==='incumbent-v1'?'incumbent-v1':['history-v1',metadata.historyPolicyId].includes(policy)?'history-v1':null;
 const opponentKey=['simple-v1',metadata.opponentPolicyId].includes(opponent)?'simple-v1':['incumbent-v1',metadata.incumbentPolicyId].includes(opponent)?'incumbent-v1':opponent==='tactical-v2'?'tactical-v2':['history-v1',metadata.historyPolicyId].includes(opponent)?'history-v1':null;
 if(!candidateKey||!opponentKey||scope!=='match')throw Error('Unsupported Hive benchmark policy/scope');
 const b={...metadata.defaultBudget,...budget};if(!Number.isFinite(b.ms)||b.ms<=0||!Number.isInteger(b.maxTurns)||b.maxTurns<1||!Number.isInteger(b.repetitionLimit)||b.repetitionLimit<2)throw Error('Invalid Hive benchmark budget');
 const start=performance.now(),candidateTimes=[],baselineTimes=[],searches=[],opponentSearches=[],positions=new Map(),opening=generateOpening({seed,openingPlies:b.openingPlies});let state=opening.state,turns=0,status='capped',error=null,illegalActions=0,replyNodes=0,reason=null;
 while(turns<b.maxTurns){
  if(state.phase==='gameover'){status='complete';break;}if(state.phase==='stalemate-review'){status='unresolved';reason='two-forced-passes';break;}
  const key=positionKey(state),visits=(positions.get(key)||0)+1;positions.set(key,visits);if(visits>=b.repetitionLimit){status='unresolved';reason='benchmark-repetition-limit';break;}
  const actor=state.currentPlayer,observation=publicObservation(state,actor),actions=legalActions(state),began=performance.now();let action;
  try{if(actor===seat){const chosen=chooseCandidate(observation,{...b,policy:candidateKey});action=chosen.action;searches.push(chosen.diagnostics);}else if(opponentKey!=='simple-v1'){const chosen=chooseCandidate(observation,{...b,policy:opponentKey});action=chosen.action;opponentSearches.push(chosen.diagnostics);}else{const chosen=chooseBaseline(observation,{seed:(seed>>>0)+turns});action=chosen.action;replyNodes+=chosen.replyNodes;}
   (actor===seat?candidateTimes:baselineTimes).push(performance.now()-began);
   if(!action||!actions.some(a=>actionKey(a)===actionKey(action)))throw Error('Policy returned illegal action');state=applyAction(state,action);assertValid(state);turns++;
  }catch(e){status='illegal';illegalActions++;error=String(e.message);break;}
 }
 if(state.phase==='gameover')status='complete';else if(state.phase==='stalemate-review'){status='unresolved';reason='two-forced-passes';}
 const result=status==='complete'?outcome(state):null,complete=status==='complete';
 return {game:metadata.game,seed,seat,players,policyId:candidateKey==='incumbent-v1'?metadata.incumbentPolicyId:candidateKey==='history-v1'?metadata.historyPolicyId:metadata.policyId,opponentPolicyId:opponentKey==='simple-v1'?metadata.opponentPolicyId:opponentKey==='incumbent-v1'?metadata.incumbentPolicyId:opponentKey==='history-v1'?metadata.historyPolicyId:metadata.policyId,budget:b,scope,status,
  shares:complete?result.shares:null,winners:complete?(result.winner===null?[0,1]:[result.winner]):null,scores:null,margin:null,
  turns,elapsedMs:performance.now()-start,latency:latency(candidateTimes),diagnostics:{illegalActions,capped:status==='capped',unresolved:status==='unresolved',error,reason:reason??result?.reason??null,
   phase:state.phase,startingPlayer:state.startingPlayer,opening:opening.diagnostics,totalPlies:state.ply,baselineLatency:latency(baselineTimes),allLatency:latency([...candidateTimes,...baselineTimes]),baselineReplyNodes:replyNodes,
   candidateNodes:searches.reduce((n,s)=>n+s.nodes,0),completedDepths:searches.map(s=>s.completedDepth),fallbackDecisions:searches.filter(s=>s.fallback).length,
   tacticalReplyNodes:searches.reduce((n,s)=>n+s.tacticalReplyNodes,0),maxFloorOverrunMs:Math.max(0,...searches.map(s=>s.floorOverrunMs)),tacticalReadyDecisions:searches.filter(s=>s.tacticalReady).length,
   historyDecisions:searches.filter(s=>s.historyPolicy).length,historySelectedRepeatedDecisions:searches.filter(s=>s.selectedRepeatedState===true).length,historySelectedPreviousOccurrences:searches.filter(s=>s.historyPolicy).map(s=>s.selectedPreviousOccurrences),
   opponentNodes:opponentSearches.reduce((n,s)=>n+s.nodes,0),opponentCompletedDepths:opponentSearches.map(s=>s.completedDepth),opponentMaxFloorOverrunMs:Math.max(0,...opponentSearches.map(s=>s.floorOverrunMs)),promotion:false}};
}
